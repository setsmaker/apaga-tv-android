package es.matrixradar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Real Bluetooth RSSI plotted as relative radial strength. Angles are arbitrary, not spatial bearings. */
public final class RadarView extends View {
    private static final int GREEN=Color.rgb(44,237,143);
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<DeviceStore.Device> devices=new ArrayList<>();
    private long initial=android.os.SystemClock.uptimeMillis();
    private boolean animating;
    private final String glyphs="010101001101";

    public RadarView(Context context){super(context);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setDevices(List<DeviceStore.Device> list){devices=new ArrayList<>(list);invalidate();}
    public void setAnimating(boolean on){animating=on;invalidate();}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,r=Math.min(w,h)*.41f;
        c.drawColor(Color.rgb(5,14,12));
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx,cy,r*1.18f,new int[]{0xFF092F25,0xFF071911,0xFF050E0C},null,Shader.TileMode.CLAMP));
        c.drawCircle(cx,cy,r*1.19f,p);p.setShader(null);
        long t=android.os.SystemClock.uptimeMillis()-initial;
        // decorative falling digital rain columns
        p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));
        p.setTextSize(dp(10));
        for(int col=0;col<22;col++){
            float x=(col+.5f)*w/22;
            float y=((t*.013f+col*71)% (h+125))-110;
            for(int row=0;row<5;row++){
                p.setColor(Color.argb(Math.max(7,27-row*5),21,235,125));
                c.drawText(glyphs.substring((col+row)%glyphs.length(),(col+row)%glyphs.length()+1),x,y+row*dp(13),p);
            }
        }
        p.setColor(0xFF0D4736);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));
        for(int j=1;j<=4;j++)c.drawCircle(cx,cy,r*j/4f,p);
        c.drawLine(cx-r,cy,cx+r,cy,p);
        c.drawLine(cx,cy-r,cx,cy+r,p);
        for(int j=0;j<24;j++){
            double a=j*Math.PI/12;
            float x1=cx+(float)Math.cos(a)*r*1.01f,y1=cy+(float)Math.sin(a)*r*1.01f;
            float x2=cx+(float)Math.cos(a)*r*1.06f,y2=cy+(float)Math.sin(a)*r*1.06f;
            p.setColor(j%6==0?0xFF3CCB88:0xFF1B6748);c.drawLine(x1,y1,x2,y2,p);
        }
        // 90-degree sweep wedge with a translucent tail
        float angle=(t%7200L)/7200f*360f;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new SweepGradient(cx,cy,new int[]{0x0000FF70,0x0B19FF82,0x8626FF98,0x0019FF80},new float[]{0f,.70f,.98f,1f}));
        c.save(); c.rotate(angle,cx,cy);c.drawCircle(cx,cy,r,p);c.restore();p.setShader(null);
        double axis=Math.toRadians(angle-7);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.5f));p.setColor(0xAA45FFA6);
        c.drawLine(cx,cy,cx+(float)Math.cos(axis)*r,cy+(float)Math.sin(axis)*r,p);
        // Real RSSI-based radial magnitude; arbitrary hash angle (Bluetooth gives no bearing).
        p.setStyle(Paint.Style.FILL);
        for(DeviceStore.Device d:devices){
            int hash=d.id.hashCode();
            double radians=((hash&0xFFFF)/65536d)*Math.PI*2;
            // -45 dBm near centre, -95 dBm towards outer ring, illustrative proximity ONLY.
            float distance=Math.min(.97f,Math.max(.15f,(-d.filteredRssi-37f)/63f));
            float px=cx+(float)Math.cos(radians)*r*distance;
            float py=cy+(float)Math.sin(radians)*r*distance;
            float glow=(float)(Math.sin(t/390d+hash)*2+6);
            p.setColor(0x2248FFC0);c.drawCircle(px,py,dp(glow+4),p);
            int spotColor = d.motion==DeviceStore.MOTION_APPROACHING?0xFFB9FFE4:
                    d.motion==DeviceStore.MOTION_RECEDING?0xFFFF8B98:0xFF31F49B;
            p.setColor(spotColor);c.drawCircle(px,py,dp(3.8f),p);
            if(d.motion==DeviceStore.MOTION_APPROACHING || d.motion==DeviceStore.MOTION_RECEDING){
                p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(12));
                c.drawText(d.motion==DeviceStore.MOTION_APPROACHING?"+":"−",px+dp(6),py-dp(6),p);
            }
            p.setColor(0xFF08231B);c.drawCircle(px,py,dp(1.3f),p);
        }
        p.setStyle(Paint.Style.FILL);p.setColor(GREEN);c.drawCircle(cx,cy,dp(4),p);
        p.setColor(0xFF70FFB6);p.setTextSize(dp(11));p.setTypeface(Typeface.MONOSPACE);
        c.drawText("2.4 GHz  /  SPECTRUM",dp(15),dp(23),p);
        p.setColor(0xFF3F8C68);p.setTextSize(dp(10));
        c.drawText("RSSI FUERTE",cx-dp(41),cy-dp(30),p);
        c.drawText("RSSI DÉBIL",cx-dp(35),cy+r+dp(20),p);
        if(animating)postInvalidateDelayed(55);
    }
    private float dp(float dp){return getResources().getDisplayMetrics().density*dp;}
}
