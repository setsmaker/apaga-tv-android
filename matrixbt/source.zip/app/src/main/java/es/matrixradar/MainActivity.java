package es.matrixradar;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Foreground-only Bluetooth LE + classic discovery. All observations stay in RAM. */
public final class MainActivity extends Activity {
    private static final int BG=0xFF050C0A, PANEL=0xFF0A1C15, LINE=0xFF1A503A,
        GREEN=0xFF41F49B, BRIGHT=0xFFB5FFDB, DIM=0xFF7FAF95, RED=0xFFF36D76,
        WHITE=0xFFE6FFF0;
    private static final int REQ_PERMISSIONS=711;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final DeviceStore store=new DeviceStore();
    private final SimpleDateFormat timeFmt=new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
    private BluetoothAdapter adapter;
    private BluetoothLeScanner bleScanner;
    private boolean isBleScan=false, isStarted=false, receiverRegistered=false, isActive=false;
    private int tickCount=0;
    private TextView mainNumber,scanState,sessionCounter,newCounter,bleCounter,classicCounter,approachCounter,departCounter,stableCounter,uncertainCounter,
        typeSummary,makersSummary,strengthSummary,stamp,listLabel;
    private LinearLayout devicesContainer;
    private RadarView radar;
    private TrendView trend;
    private Button startStop,classicButton;

    private final ScanCallback bleCallback=new ScanCallback() {
        @Override public void onScanResult(int callbackType,ScanResult result){
            if(result==null)return;
            runOnUiThread(()->acceptBle(result));
        }
        @Override public void onBatchScanResults(List<ScanResult> results){
            for(ScanResult result:results)runOnUiThread(()->acceptBle(result));
        }
        @Override public void onScanFailed(int code){
            runOnUiThread(()->{isBleScan=false;setStatus("BLE ERROR "+code+" · revisa Bluetooth", RED);});
        }
    };

    private final BroadcastReceiver classicReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent) {
            if(intent==null)return;
            String action=intent.getAction();
            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                BluetoothDevice device;
                if(Build.VERSION.SDK_INT>=33)device=intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE,BluetoothDevice.class);
                else device=intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(device==null)return;
                try {
                    String id=device.getAddress();
                    String name=safeName(device);
                    BluetoothClass cls=device.getBluetoothClass();
                    int major=cls==null?0:cls.getMajorDeviceClass();
                    int rssi=intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,(short)-95);
                    store.update(id,name,DeviceStore.guessCategory(name,major),DeviceStore.guessMaker(name,-1),rssi,false,System.currentTimeMillis());
                }catch(SecurityException ignored){}
            }else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                if(isStarted)setStatus(isBleScan?"RADAR ACTIVO · BLE + EXPLORACIÓN CLÁSICA":"EXPLORACIÓN CLÁSICA TERMINADA",GREEN);
            }
        }
    };

    private final Runnable ticker=new Runnable(){
        @Override public void run(){
            if(!isActive)return;
            updateDisplay();
            if(isStarted){
                tickCount++;
                if(tickCount%12==0)startClassicDiscovery();
            }
            handler.postDelayed(this,5000);
        }
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        BluetoothManager bm=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter=bm==null?null:bm.getAdapter();
        buildScreen();
        IntentFilter filter=new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(classicReceiver,filter);
        receiverRegistered=true;
    }

    @Override protected void onResume(){
        super.onResume();isActive=true;radar.setAnimating(true);
        handler.removeCallbacks(ticker);handler.post(ticker);
        if(isStarted && !isBleScan && hasPermissions())startScanning(false);
    }
    @Override protected void onPause(){
        isActive=false;handler.removeCallbacks(ticker);radar.setAnimating(false);
        stopRadio();super.onPause();
    }
    @Override protected void onDestroy(){
        if(receiverRegistered){try{unregisterReceiver(classicReceiver);}catch(Exception ignored){}}
        super.onDestroy();
    }

    private void buildScreen(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(17),dp(19),dp(17),dp(35));
        scroll.addView(page);

        TextView eyebrow=label("◉  M A T R I X   /   B T   R A D A R",13,GREEN,true);
        add(page,eyebrow,6);
        add(page,label("BLUETOOTH // SPECTRUM ANALYZER",11,DIM,false),17);

        LinearLayout header=card();
        TextView tag=label("DISPOSITIVOS ACTIVOS",12,DIM,true);
        add(header,tag,1);
        mainNumber=label("00",86,BRIGHT,true);
        mainNumber.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));
        mainNumber.setShadowLayer(dp(22),0,0,0x662BFF91);
        add(header,mainNumber,-2);
        scanState=label("●  SISTEMA EN ESPERA",13,DIM,true);
        add(header,scanState,7);
        add(header,label("VENTANA DE 25 S  ·  ACTUALIZACIÓN CADA 5 S",10,DIM,false),3);
        add(page,header,11);

        radar=new RadarView(this);
        LinearLayout radarFrame=card();
        LinearLayout.LayoutParams radarParams=new LinearLayout.LayoutParams(-1,dp(310));
        radarFrame.addView(radar,radarParams);
        add(radarFrame,label("RADIO APROX. POR RSSI · ÁNGULO SIMULADO (SIN DIRECCIÓN REAL)",10,DIM,false),2);
        add(page,radarFrame,12);

        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        sessionCounter=metric(row,"TOTAL SESIÓN","0");
        newCounter=metric(row,"NUEVOS / 5 S","0");
        add(page,row,9);
        LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);
        bleCounter=metric(row2,"BLE / LE","0");
        classicCounter=metric(row2,"CLÁSICOS","0");
        add(page,row2,12);
        add(page,section("MOVIMIENTO ESTIMADO", "VARIACIÓN RSSI / 15-25 S"),8);
        LinearLayout movementRow=new LinearLayout(this);movementRow.setOrientation(LinearLayout.HORIZONTAL);
        approachCounter=metric(movementRow,"↘ SE ACERCAN","0");
        departCounter=metric(movementRow,"↗ SE ALEJAN","0");
        add(page,movementRow,9);
        LinearLayout movementRow2=new LinearLayout(this);movementRow2.setOrientation(LinearLayout.HORIZONTAL);
        stableCounter=metric(movementRow2,"= ESTABLES","0");
        uncertainCounter=metric(movementRow2,"? SIN TENDENCIA","0");
        add(page,movementRow2,8);
        add(page,label("INDICIOS POR POTENCIA DE SEÑAL · NO CONFIRMA MOVIMIENTO. Se necesitan varias lecturas durante al menos 15 s.",11,DIM,false),14);

        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);
        startStop=button("▶  INICIAR RADAR",0xFF0C5C38,WHITE,16);
        addHeight(controls,startStop,62,9);
        classicButton=button("⌁  BUSCAR BLUETOOTH CLÁSICO",PANEL,GREEN,13);
        addHeight(controls,classicButton,54,7);
        add(page,controls,18);
        startStop.setOnClickListener(v->{
            if(isStarted){isStarted=false;stopRadio();setStatus("RADAR DETENIDO",DIM);updateControls();}
            else requestStart();
        });
        classicButton.setOnClickListener(v->{if(!isStarted)requestStart();else startClassicDiscovery();});

        add(page,section("HISTORIAL DE ACTIVIDAD", "ÚLTIMAS 2 MINUTOS"),10);
        LinearLayout chartCard=card();
        trend=new TrendView(this);
        chartCard.addView(trend,new LinearLayout.LayoutParams(-1,dp(104)));
        stamp=label("SIN LECTURAS",11,DIM,false);add(chartCard,stamp,0);
        add(page,chartCard,19);

        add(page,section("ANÁLISIS DEL ENTORNO", "CLASIFICACIÓN ESTIMADA"),9);
        LinearLayout cat=card();
        typeSummary=label("ESPERANDO ESCANEO",13,GREEN,false);
        typeSummary.setTypeface(Typeface.MONOSPACE);
        add(cat,typeSummary,10);
        makersSummary=label("MARCAS / FABRICANTES: —",12,DIM,false);
        add(cat,makersSummary,10);
        strengthSummary=label("RSSI  ·  FUERTE —   MEDIA —   DÉBIL —",12,DIM,false);
        add(cat,strengthSummary,0);
        add(page,cat,18);

        add(page,section("SEÑALES DETECTADAS", "MÁX. 12 EN PANTALLA"),8);
        listLabel=label("Aún no hay dispositivos visibles",12,DIM,false);add(page,listLabel,7);
        devicesContainer=new LinearLayout(this);
        devicesContainer.setOrientation(LinearLayout.VERTICAL);add(page,devicesContainer,13);
        add(page,label("AVISO // Los contadores representan identificadores recibidos, no personas. BLE puede cambiar de dirección. La variación RSSI depende también de obstáculos, interferencias, reflejos y orientación: 'acercándose' y 'alejándose' son indicios, no certezas. Las posiciones angulares del radar son ilustrativas y no mide la dirección ni la distancia real. Nada sale del teléfono.",11,DIM,false),11);
        updateControls();
        setContentView(scroll);
    }

    private TextView metric(LinearLayout row,String title,String initial){
        LinearLayout panel=card();
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);
        lp.rightMargin=dp(5);row.addView(panel,lp);
        add(panel,label(title,10,DIM,true),6);
        TextView big=label(initial,32,GREEN,true);big.setTypeface(Typeface.MONOSPACE);
        add(panel,big,0);
        return big;
    }
    private View section(String left,String right){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView a=label(left,12,GREEN,true);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));
        r.addView(label(right,9,DIM,false));return r;
    }
    private LinearLayout card(){
        LinearLayout l=new LinearLayout(this);l.setPadding(dp(15),dp(13),dp(15),dp(13));
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable b=new GradientDrawable();b.setColor(PANEL);b.setCornerRadius(dp(9));b.setStroke(dp(1),LINE);
        l.setBackground(b);return l;
    }
    private TextView label(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(color);t.setTypeface(Typeface.create(Typeface.MONOSPACE,bold?Typeface.BOLD:Typeface.NORMAL));
        return t;
    }
    private Button button(String text,int background,int foreground,int size){
        Button b=new Button(this);b.setText(text);b.setTextColor(foreground);
        b.setTextSize(size);b.setAllCaps(false);
        b.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
        GradientDrawable shape=new GradientDrawable();shape.setColor(background);shape.setCornerRadius(dp(8));shape.setStroke(dp(1),0xFF228A5A);
        b.setBackground(shape);return b;
    }
    private void add(LinearLayout row,View view,int bottom){
        LinearLayout.LayoutParams l=new LinearLayout.LayoutParams(-1,-2);
        l.bottomMargin=dp(Math.max(0,bottom));row.addView(view,l);
    }
    private void addHeight(LinearLayout row,View view,int height,int bottom){
        LinearLayout.LayoutParams l=new LinearLayout.LayoutParams(-1,dp(height));l.bottomMargin=dp(bottom);row.addView(view,l);
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}

    private void setStatus(String s,int color){if(scanState!=null){scanState.setText("●  "+s);scanState.setTextColor(color);}}
    private boolean hasPermissions(){
        if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return Build.VERSION.SDK_INT<23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestStart(){
        if(adapter==null){setStatus("SIN ADAPTADOR BLUETOOTH",RED);return;}
        if(!hasPermissions()){
            if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_PERMISSIONS);
            else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_PERMISSIONS);
            return;
        }
        startScanning(true);
    }
    @Override public void onRequestPermissionsResult(int req,String[] names,int[] grants){
        super.onRequestPermissionsResult(req,names,grants);
        if(req==REQ_PERMISSIONS){
            if(hasPermissions())startScanning(true);
            else setStatus("PERMISO DENEGADO · ACTIVAR DISPOSITIVOS CERCANOS",RED);
        }
    }
    private void startScanning(boolean fresh){
        try {
            if(adapter==null){setStatus("NO SE HA ENCONTRADO BLUETOOTH",RED);return;}
            if(!adapter.isEnabled()){
                setStatus("ACTIVA BLUETOOTH Y VUELVE AL RADAR",RED);
                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                return;
            }
            if(fresh){store.clear();tickCount=0;trend.invalidate();}
            bleScanner=adapter.getBluetoothLeScanner();
            if(bleScanner==null){setStatus("BLE NO DISPONIBLE EN ESTE MÓVIL",RED);return;}
            if(!isBleScan){
                ScanSettings settings=new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
                bleScanner.startScan(null,settings,bleCallback);
                isBleScan=true;
            }
            isStarted=true;setStatus("ESCANEO BLE EN TIEMPO REAL",GREEN);
            updateControls();
            if(fresh)startClassicDiscovery();
        }catch(SecurityException e){setStatus("FALTAN PERMISOS BLUETOOTH",RED);}
        catch(RuntimeException e){setStatus("ERROR AL INICIAR ESCANEO",RED);}
    }
    private void startClassicDiscovery(){
        if(adapter==null || !hasPermissions() || !isStarted)return;
        try{
            if(!adapter.isDiscovering()){
                boolean started=adapter.startDiscovery();
                if(started)setStatus("RADAR ACTIVO · BLE + CLÁSICO",GREEN);
            }
        }catch(SecurityException e){setStatus("PERMISO DE EXPLORACIÓN REQUERIDO",RED);}
    }
    private void stopRadio(){
        if(bleScanner!=null && isBleScan){try{bleScanner.stopScan(bleCallback);}catch(Exception ignored){}}
        isBleScan=false;
        if(adapter!=null){try{if(hasPermissions() && adapter.isDiscovering())adapter.cancelDiscovery();}catch(Exception ignored){}}
        updateControls();
    }
    private void updateControls(){
        if(startStop!=null)startStop.setText(isStarted?"■  DETENER RADAR":"▶  INICIAR RADAR");
    }
    private String safeName(BluetoothDevice d){try{return d.getName();}catch(Exception ex){return null;}}
    private void acceptBle(ScanResult result){
        if(!isStarted)return;
        try {
            BluetoothDevice d=result.getDevice();if(d==null)return;
            String id=d.getAddress();
            ScanRecord record=result.getScanRecord();
            String name=record==null?null:record.getDeviceName();
            if(name==null || name.isEmpty())name=safeName(d);
            int mfg=-1;
            if(record!=null){
                SparseArray<byte[]> ids=record.getManufacturerSpecificData();
                if(ids!=null && ids.size()>0)mfg=ids.keyAt(0);
            }
            int major=0;
            try{BluetoothClass btClass=d.getBluetoothClass();if(btClass!=null)major=btClass.getMajorDeviceClass();}catch(Exception ignored){}
            store.update(id,name,DeviceStore.guessCategory(name,major),DeviceStore.guessMaker(name,mfg),result.getRssi(),true,System.currentTimeMillis());
        }catch(SecurityException ignored){}
    }

    private void updateDisplay(){
        if(mainNumber==null)return;
        DeviceStore.Summary s=store.snapshot(System.currentTimeMillis());
        int active=s.active.size();
        mainNumber.setText(String.format(Locale.ROOT,"%02d",active));
        sessionCounter.setText(String.valueOf(s.session));newCounter.setText(String.valueOf(s.newIn5s));
        bleCounter.setText(String.valueOf(s.ble));classicCounter.setText(String.valueOf(s.classic));
        approachCounter.setText(String.valueOf(s.approaching));departCounter.setText(String.valueOf(s.receding));
        stableCounter.setText(String.valueOf(s.stable));uncertainCounter.setText(String.valueOf(s.unknown));
        radar.setDevices(s.active);
        if(isStarted)trend.addSample(active);
        stamp.setText("ÚLTIMA LECTURA   "+timeFmt.format(new Date())+"   /   CICLO: 05 S");
        typeSummary.setText(formatMap(s.categoryCounts,"TIPO"));
        makersSummary.setText(formatMap(s.makerCounts,"FABRICANTE · ESTIMADO"));
        strengthSummary.setText("RSSI  ■ FUERTE "+s.strong+"    ◧ MEDIA "+s.medium+"    ◦ DÉBIL "+s.weak);
        listLabel.setText(active==0?"No se han recibido señales recientes":"ORDENADOS POR INTENSIDAD RSSI · VISIBLES AHORA");
        devicesContainer.removeAllViews();
        for(int i=0;i<Math.min(12,active);i++)addDevice(s.active.get(i));
    }
    private String formatMap(Map<String,Integer> map,String head){
        StringBuilder s=new StringBuilder(head+"\n");
        if(map.isEmpty())return s.append("SIN DATOS").toString();
        List<Map.Entry<String,Integer>> entries=new ArrayList<>(map.entrySet());
        entries.sort((a,b)->Integer.compare(b.getValue(),a.getValue()));
        for(int i=0;i<Math.min(entries.size(),7);i++){
            Map.Entry<String,Integer> e=entries.get(i);
            s.append("• ").append(e.getKey()).append("  ").append(e.getValue()).append("\n");
        }
        return s.toString().trim();
    }
    private void addDevice(DeviceStore.Device d){
        LinearLayout card=card();
        String name=d.name.isEmpty()?"DISPOSITIVO SIN NOMBRE":d.name;
        if(name.length()>32)name=name.substring(0,29)+"…";
        add(card,label("◉  "+name,14,BRIGHT,true),5);
        String address=d.id;
        String tag=address.length()>=5?"••:••:"+address.substring(address.length()-5):"ID OCULTO";
        add(card,label(d.category+"    ·    "+d.maker,11,GREEN,false),5);
        String motion=d.motion==DeviceStore.MOTION_APPROACHING?"↘  POSIBLE ACERCAMIENTO":
              d.motion==DeviceStore.MOTION_RECEDING?"↗  POSIBLE ALEJAMIENTO":
              d.motion==DeviceStore.MOTION_STABLE?"=  SEÑAL ESTABLE":"?  DATOS INSUFICIENTES";
        int movementColor=d.motion==DeviceStore.MOTION_APPROACHING?BRIGHT:
             d.motion==DeviceStore.MOTION_RECEDING?RED:DIM;
        add(card,label(motion+(d.motion==DeviceStore.MOTION_UNKNOWN?"":"  "+
                (d.trendDelta>0?"+":"")+d.trendDelta+" dB"),11,movementColor,true),5);
        add(card,label((d.ble?"BLE ":"")+(d.classic?"CLÁSICO ":"")+"    RSSI "+Math.round(d.filteredRssi)+" dBm    ·    "+tag,11,DIM,false),0);
        add(devicesContainer,card,7);
    }
}
