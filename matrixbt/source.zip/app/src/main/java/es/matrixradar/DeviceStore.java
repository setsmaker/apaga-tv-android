package es.matrixradar;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Transient Bluetooth observations. Approximate trends, never direction or distance. */
public final class DeviceStore {
    public static final int ACTIVE_WINDOW_MS = 25000;
    public static final int CLASSIC_WINDOW_MS = 55000;
    public static final int MOTION_UNKNOWN = 2;
    public static final int MOTION_STABLE = 0;
    public static final int MOTION_APPROACHING = 1;
    public static final int MOTION_RECEDING = -1;
    private static final long BUCKET_MS = 5000;

    private static final class Sample {
        final long bucket;
        final float rssi;
        Sample(long bucket,float rssi){this.bucket=bucket;this.rssi=rssi;}
    }

    public static final class Device {
        public final String id;
        public String name = "";
        public String category = "OTRO";
        public String maker = "DESCONOCIDO";
        public int rssi = -100;
        public float filteredRssi = -100;
        public int motion = MOTION_UNKNOWN;
        public int trendDelta = 0;
        public long firstSeen;
        public long lastSeen;
        public boolean ble;
        public boolean classic;
        private long bucketId = Long.MIN_VALUE;
        private long sum;
        private int count;
        private final ArrayDeque<Sample> history=new ArrayDeque<>();

        Device(String id,long now){this.id=id;this.firstSeen=now;this.lastSeen=now;}

        boolean active(long now){return now-lastSeen <= (classic && !ble ? CLASSIC_WINDOW_MS : ACTIVE_WINDOW_MS);}
        void capture(int value,long now){
            if(value>0 || value < -127)return;
            long epoch=now / BUCKET_MS;
            if(bucketId!=epoch){flush();bucketId=epoch;sum=0;count=0;}
            sum+=value;count++;
            rssi=value;
        }
        void flush(){
            if(count>0){
                float avg=sum/(float)count;
                history.addLast(new Sample(bucketId,avg));
                while(history.size()>7)history.removeFirst();
                float a=history.peekLast().rssi;
                float b=history.size()>1?nthFromLast(1).rssi:a;
                filteredRssi=(2*a+b)/3f;
            }
            sum=0;count=0;
        }
        private Sample nthFromLast(int steps){
            Iterator<Sample> it=history.descendingIterator();
            Sample v=null;
            for(int k=0;k<=steps&&it.hasNext();k++)v=it.next();
            return v;
        }
        void assess(long now){
            // Only close complete 5s buckets; current readings belong to the next tick.
            if(bucketId < now/BUCKET_MS){flush();bucketId=now/BUCKET_MS;}
            motion=MOTION_UNKNOWN;trendDelta=0;
            if(!ble || now-lastSeen>10000L || history.size()<4)return;
            List<Sample> samples=new ArrayList<>(history);
            int n=samples.size();
            samples=samples.subList(Math.max(0,n-5),n);
            for(int i=1;i<samples.size();i++){
                long gap=samples.get(i).bucket-samples.get(i-1).bucket;
                if(gap>2 || gap<=0)return;
            }
            Sample oldest=samples.get(0),latest=samples.get(samples.size()-1);
            if(latest.bucket-oldest.bucket<3 || now/BUCKET_MS-latest.bucket>2)return;
            float prior=(samples.get(0).rssi+samples.get(1).rssi)/2f;
            float recent=(samples.get(samples.size()-1).rssi+samples.get(samples.size()-2).rssi)/2f;
            float delta=recent-prior;
            trendDelta=Math.round(delta);
            // Require a sustained change greater than normal short-term RSSI noise.
            if(delta>=7f && latest.rssi>=oldest.rssi+5f)motion=MOTION_APPROACHING;
            else if(delta<=-7f && latest.rssi<=oldest.rssi-5f)motion=MOTION_RECEDING;
            else motion=MOTION_STABLE;
        }
    }

    public static final class Summary {
        public final List<Device> active;
        public final int session,newIn5s,ble,classic,strong,medium,weak,approaching,receding,stable,unknown;
        public final Map<String,Integer> categoryCounts;
        public final Map<String,Integer> makerCounts;
        Summary(List<Device> active,int session,int newIn5s,int ble,int classic,int strong,int medium,int weak,
                int approaching,int receding,int stable,int unknown,
                Map<String,Integer> categoryCounts,Map<String,Integer> makerCounts){
            this.active=active;this.session=session;this.newIn5s=newIn5s;this.ble=ble;this.classic=classic;
            this.strong=strong;this.medium=medium;this.weak=weak;
            this.approaching=approaching;this.receding=receding;this.stable=stable;this.unknown=unknown;
            this.categoryCounts=categoryCounts;this.makerCounts=makerCounts;
        }
    }

    private final Map<String,Device> devices=new HashMap<>();
    private int sessionCount=0;
    public synchronized void clear(){devices.clear();sessionCount=0;}
    public synchronized void update(String id,String name,String category,String maker,int rssi,boolean ble,long now){
        if(id==null||id.isEmpty())return;
        Device d=devices.get(id);
        if(d==null){d=new Device(id,now);devices.put(id,d);sessionCount++;}
        if(name!=null&&!name.trim().isEmpty())d.name=name.trim();
        if(category!=null&&!category.equals("OTRO"))d.category=category;
        if(maker!=null&&!maker.equals("DESCONOCIDO"))d.maker=maker;
        d.capture(rssi,now);
        d.lastSeen=now;
        if(ble)d.ble=true;else d.classic=true;
    }
    public synchronized Summary snapshot(long now){
        List<Device> active=new ArrayList<>();
        int fresh=0,ble=0,classic=0,strong=0,med=0,weak=0,approaching=0,receding=0,stable=0,unknown=0;
        Map<String,Integer> cats=new HashMap<>(),makers=new HashMap<>();
        Iterator<Map.Entry<String,Device>> it=devices.entrySet().iterator();
        while(it.hasNext()){
            Device d=it.next().getValue();
            if(now-d.lastSeen>600000L){it.remove();continue;}
            if(!d.active(now))continue;
            d.assess(now);
            active.add(d);
            if(now-d.firstSeen<=5000)fresh++;
            if(d.ble)ble++;
            if(d.classic)classic++;
            if(d.filteredRssi>=-65)strong++;else if(d.filteredRssi>=-80)med++;else weak++;
            if(d.motion==MOTION_APPROACHING)approaching++;
            else if(d.motion==MOTION_RECEDING)receding++;
            else if(d.motion==MOTION_STABLE)stable++;
            else unknown++;
            cats.put(d.category,cats.getOrDefault(d.category,0)+1);
            makers.put(d.maker,makers.getOrDefault(d.maker,0)+1);
        }
        Collections.sort(active,(a,b)->Float.compare(b.filteredRssi,a.filteredRssi));
        return new Summary(active,sessionCount,fresh,ble,classic,strong,med,weak,
                approaching,receding,stable,unknown,cats,makers);
    }
    public static String guessCategory(String name,int majorClass){
        String n=(name==null?"":name).toLowerCase(Locale.ROOT);
        if(majorClass==0x200 || n.matches(".*(iphone|pixel [0-9]|galaxy s|galaxy a[0-9]|redmi|oneplus|smartphone).*"))return "MÓVIL";
        if(majorClass==0x100 || n.matches(".*(macbook|notebook|laptop|thinkpad|windows|desktop|surface pro).*"))return "ORDENADOR";
        if(majorClass==0x700 || n.matches(".*(garmin|fitbit|watch|mi band|smartband|vivosmart|forerunner).*"))return "RELOJ";
        if(n.matches(".*(carplay|bmw|mercedes|audi |volkswagen|skoda|seat |peugeot|renault|ford sync|toyota|nissan|kia |hyundai|car audio|handsfree car).*"))return "COCHE";
        if(majorClass==0x400 || n.matches(".*(airpods|buds|earbuds|headset|headphone|speaker|jbl|soundbar|bose|beats|sony wh-|sony wf-).*"))return "AUDIO";
        if(n.matches(".*(beacon|airtag|tile|smarttag|tracker|find my|tag[0-9]).*"))return "RASTREADOR";
        if(majorClass==0x500 || majorClass==0x800)return "ACCESORIO";
        return "OTRO";
    }
    public static String guessMaker(String name,int manufacturerId){
        switch(manufacturerId){
            case 0x004C:return "APPLE";
            case 0x0075:return "SAMSUNG";
            case 0x00E0:return "GOOGLE";
            case 0x0006:return "MICROSOFT";
            case 0x0059:return "NORDIC";
            default:break;
        }
        String n=(name==null?"":name).toLowerCase(Locale.ROOT);
        if(n.contains("samsung")||n.contains("galaxy"))return "SAMSUNG";
        if(n.contains("apple")||n.contains("iphone")||n.contains("airpods"))return "APPLE";
        if(n.contains("xiaomi")||n.contains("redmi"))return "XIAOMI";
        if(n.contains("huawei")||n.contains("honor"))return "HUAWEI / HONOR";
        if(n.contains("sony"))return "SONY";
        if(n.contains("jbl"))return "JBL";
        if(n.contains("garmin"))return "GARMIN";
        if(n.contains("bose"))return "BOSE";
        if(n.contains("fitbit")||n.contains("pixel"))return "GOOGLE";
        if(n.contains("lg"))return "LG";
        return "DESCONOCIDO";
    }
}
