package es.matrixradar;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public final class TrendView extends View {
    private final List<Integer> history=new ArrayList<>();
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public TrendView(Context c){super(c);}
    public void addSample(int n){history.add(n);if(history.size()>24)history.remove(0);invalidate();}
    @Override protected void onDraw(Canvas c){
        float w=getWidth(),h=getHeight(),pad=12;
        p.setStrokeWidth(1);p.setColor(0xFF143E2E);
        for(int i=1;i<=3;i++)c.drawLine(0,h*i/4,w,h*i/4,p);
        if(history.isEmpty())return;
        int max=5;for(int n:history)max=Math.max(max,n);
        Path path=new Path();
        for(int i=0;i<history.size();i++){
            float x=history.size()==1?w/2f:(w-pad*2)*(i/(float)(history.size()-1))+pad;
            float y=h-pad-(history.get(i)/(float)max)*(h-2*pad);
            if(i==0)path.moveTo(x,y);else path.lineTo(x,y);
        }
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFF48EF9D);c.drawPath(path,p);
        p.setStyle(Paint.Style.FILL);
    }
}
