# MATRIX BT RADAR — Android

Aplicación Android independiente con estética de terminal Matrix: radar animado, detección de dispositivos Bluetooth LE y Bluetooth clásico visibles. Sin Internet, anuncios ni cuenta.

## Lecturas reales y tendencias de movimiento estimado

- Contador de identificadores activos refrescado **cada 5 segundos**. La ventana para considerar un BLE activo es de 25 s; la de Bluetooth clásico, de 55 s.
- **Se acercan / Se alejan / Estables / Sin tendencia:** a partir de la evolución de las muestras de potencia recibida (RSSI) agrupadas en ventanas de 5 s. Se requieren al menos cuatro ventanas observadas (15 segundos entre extremos) y un cambio sostenido de aproximadamente 7 dB entre el principio y el final.
- Si el dispositivo no ha emitido suficientes datos o se pierde, **no se le inventa una dirección de movimiento**.
- Puntos de radar con radio basado en RSSI filtrado. El **ángulo de cada punto es ilustrativo**, derivado de su identificador para mantener una posición visual estable; Bluetooth no permite saber hacia dónde está el dispositivo. **No mide una distancia real**.
- Total de identificadores de la sesión, nuevos en 5 s, BLE y clásicos, clases estimadas, fabricantes, intensidad, historial de detecciones.

## Limitaciones

Un RSSI creciente es compatible con que el dispositivo se acerque, pero también cambia por paredes, movimiento del teléfono, antenas, reflejos, interferencias, potencia de transmisión y posición del cuerpo. Los contadores indican **tendencia de señal**, no seguimiento fiable ni conteo de personas. Los dispositivos que dejan de emitir o usan direcciones Bluetooth cambiantes pueden desaparecer, reaparecer o contarse varias veces. Teléfonos no detectables no aparecen. La clasificación por fabricante o tipo es tentativa.

## Privacidad y permisos

El radar solo funciona con la app visible en primer plano; al pasar a segundo plano, detiene el escaneo. No envía datos, ni guarda direcciones o nombres fuera de la RAM. En Android 12+ pide acceso a **Dispositivos cercanos**; según teléfono y versión, para detectar Bluetooth clásico puede requerirse activar la ubicación del sistema. No requiere ubicación GPS para mostrar las tendencias.

## Compilar

El repositorio contiene un proyecto Android Java sin dependencias externas, SDK 35, Gradle 8.9, Android Gradle Plugin 8.7.3 y Java 17. La acción de GitHub 1Compilar Matrix BT Radar2 genera el APK debug.
